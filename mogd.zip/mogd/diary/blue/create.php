<?php
require '../common/core_create.php';