<?php
require '../common/core_edit.php';