<?php
require '../common/core_index.php';