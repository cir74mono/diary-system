<?php
require '../common/core_res.php';