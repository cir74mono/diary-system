<?php
require '../common/core_search.php';