<?php
require '../common/core_thread.php';