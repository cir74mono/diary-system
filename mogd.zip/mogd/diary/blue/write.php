<?php
require '../common/core_write.php';