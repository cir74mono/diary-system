<footer class="site-footer">
    (c) <?= date('Y') ?> mogd.
</footer>